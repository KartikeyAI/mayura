// Explicit owner tooling: one disposable Starter index, synthetic data, no inference or plan changes.
import {randomUUID,createHash} from 'node:crypto';
import {readFile,mkdir,writeFile,rename} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';
import {pineconeVectorStore} from '../extensions/vector-pinecone/dist/index.js';
import {qualifyRagAdapters} from './live/rag-checks.mjs';
import {pineconeLoadProfile,pineconeLoadWorkDuration,publicDocumentationCorpus,qualifyPineconeLoad} from './live/pinecone-load-checks.mjs';
import {pineconeQueryTimings} from './live/pinecone-query-timings.mjs';

const version='2025-10';
const fail=code=>{throw Object.assign(new Error(code),{code});};

/** Static diagnostics only: provider messages, URLs, headers and credentials never enter reports. */
export function pineconeFailureCode(error) {
  const allowed=['UND_ERR_CONNECT_TIMEOUT','UND_ERR_HEADERS_TIMEOUT','UND_ERR_BODY_TIMEOUT','UND_ERR_SOCKET',
    'ECONNRESET','ECONNREFUSED','ENOTFOUND','EAI_AGAIN','ETIMEDOUT','ABORT_ERR',
    'REQUEST_BYTE_LIMIT','RESPONSE_BYTE_LIMIT','READ_UNIT_LIMIT','DATA_OPERATION_LIMIT'];
  for(const code of [error?.code,error?.cause?.code,error?.cause?.cause?.code])if(allowed.includes(code))return code;
  return error?.name==='TimeoutError'?'TIMEOUT':error?.name==='AbortError'?'ABORTED':error?.name==='SyntaxError'?'INVALID_JSON':'UNCLASSIFIED';
}
const pause=(ms,signal)=>new Promise((resolve,reject)=>{
  const finish=()=>{clearTimeout(timer);signal.removeEventListener('abort',abort);resolve();};
  const abort=()=>{clearTimeout(timer);signal.removeEventListener('abort',abort);reject(new Error('CANCELLED'));};
  const timer=setTimeout(finish,ms);signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();
});

/** Destructive cleanup is permitted only for the exact invocation's index and ownership tag. */
export function ownsPineconeIndex(index,name,owner) {
  return index?.name===name&&index?.tags?.['mayura-owner']===owner;
}

/**
 * Qualify the native adapter within a user-confirmed Starter allowance. A project key cannot audit billing.
 * There are at most 32 provisioning and 32 cleanup requests, 154 adapter operations, five fixture vectors,
 * and one create/delete attempt each. Acknowledged reads may be polled; writes are never replayed.
 */
export async function qualifyPineconeStarter(options) {
  if(options?.starterConfirmed!==true||options.maxCostMicros!==0)fail('STARTER_ZERO_COST_REQUIRED');
  if(options.profile!==undefined&&!['compatibility','load'].includes(options.profile))fail('INVALID_PROFILE');
  const load=options.profile==='load';const loadProfile=load?pineconeLoadProfile(options.loadProfile):undefined;
  const grants=['rag:qualify','rag:transport:pinecone','rag:admin:pinecone'];
  if(load)grants.push('rag:qualify:load');
  if(!grants.every(grant=>options.permissions?.allow?.includes(grant)))fail('PERMISSION_DENIED');
  if(typeof options.apiKey!=='string'||!options.apiKey.trim())fail('MISSING_CREDENTIAL');
  const owner=randomUUID();const name=`mayura-ragq-${owner.replaceAll('-','')}`;
  const report={format:1,kind:'pinecone-starter-qualification',startedAt:new Date().toISOString(),status:'failed',
    ragStatus:'experimental',productionReady:false,apiVersion:version,
    resource:{name,owner,dimensions:1536,metric:'cosine',cloud:'aws',region:'us-east-1'},
    limits:{maxCostMicros:0,maxAdapterOperations:154,maxProvisionRequests:32,maxCleanupRequests:32,fixtureVectors:5},
    billing:{plan:'Starter',verification:'User confirmed; project key cannot audit billing or remaining monthly allowance.',
      inferenceCalls:0,pricingSource:'https://www.pinecone.io/pricing/'},
    requests:{provision:0,cleanup:0,data:0},indexCleanup:'not-created'};
  if(load){
    report.kind='pinecone-starter-load-qualification';report.loadProfile=loadProfile;
    report.limits={...report.limits,maxAdapterOperations:loadProfile.maxOperations,maxDataRequests:1200,fixtureVectors:loadProfile.totalVectors,
      maxRequestBytes:300*1024*1024,maxResponseBytes:200*1024*1024,maxReadUnits:10000,maxWorkDurationMs:pineconeLoadWorkDuration(loadProfile)};
    report.usage={requestBytes:0,responseBytes:0,reportedReadUnits:0,readsWithUsage:0,readsWithoutUsage:0,reservedReadUnits:0};
  }
  const transport=options.fetch??globalThis.fetch;const controller=new AbortController();
  const queryTimings=load?pineconeQueryTimings():undefined;
  const abort=()=>controller.abort();options.signal?.addEventListener('abort',abort,{once:true});if(options.signal?.aborted)abort();
  const deadline=setTimeout(abort,load?report.limits.maxWorkDurationMs:240_000);let attempted=false;let creationUncertain=false;let initialNames;
  const persist=()=>options.onReport?.(report);
  const control=async(method,path,body,signal,phase)=>{
    signal.throwIfAborted();if(++report.requests[phase]>32)fail('CONTROL_OPERATION_LIMIT');
    const response=await transport(`https://api.pinecone.io${path}`,{method,redirect:'error',
      headers:{'Api-Key':options.apiKey,'X-Pinecone-Api-Version':version,'Content-Type':'application/json'},
      ...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.any([signal,AbortSignal.timeout(15_000)])});
    if(response.status===404){await response.body?.cancel();return undefined;}
    if(!response.ok){report.lastHttpStatus=response.status;await response.body?.cancel();fail('CONTROL_REJECTED');}
    if(method==='DELETE'){await response.body?.cancel();return {};}
    // Control responses are small and streamed under a hard cap; never persist raw errors or credentials.
    const reader=response.body?.getReader();let text='';let bytes=0;const decoder=new TextDecoder('utf-8',{fatal:true});
    if(!reader)fail('INVALID_CONTROL_RESPONSE');
    try{for(;;){const part=await reader.read();if(part.done)break;bytes+=part.value.length;if(bytes>262_144)fail('CONTROL_RESPONSE_LIMIT');text+=decoder.decode(part.value,{stream:true});}text+=decoder.decode();}
    finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
    return JSON.parse(text);
  };
  const describe=(signal,phase)=>control('GET',`/indexes/${name}`,undefined,signal,phase);
  try{
    const listed=await control('GET','/indexes',undefined,controller.signal,'provision');
    if(!Array.isArray(listed?.indexes)||listed.indexes.some(index=>typeof index.name!=='string'))fail('INVALID_INDEX_LIST');
    initialNames=listed.indexes.map(index=>index.name).sort();
    if(initialNames.includes(name)||initialNames.length>=5)fail('NO_FREE_INDEX_SLOT');
    report.status='running';report.indexCleanup='pending';await persist();attempted=true;
    options.progress?.('Creating one disposable Starter index');
    creationUncertain=true;
    await control('POST','/indexes',{name,vector_type:'dense',dimension:1536,metric:'cosine',deletion_protection:'disabled',
      spec:{serverless:{cloud:'aws',region:'us-east-1'}},tags:{'mayura-owner':owner,'mayura-purpose':'rag-qualification'}},controller.signal,'provision');
    creationUncertain=false;
    let index;
    for(let attempt=0;attempt<30;attempt++){
      index=await describe(controller.signal,'provision');
      if(index&&!ownsPineconeIndex(index,name,owner))fail('OWNERSHIP_MISMATCH');
      if(index?.status?.ready)break;await pause(2000,controller.signal);
    }
    if(!index?.status?.ready)fail('INDEX_NOT_READY');
    if(index.dimension!==1536||index.metric!=='cosine'||index.vector_type!=='dense'||index.embed
      ||index.spec?.serverless?.cloud!=='aws'||index.spec?.serverless?.region!=='us-east-1'
      ||index.spec?.serverless?.read_capacity?.mode==='Dedicated')fail('INDEX_PROFILE_MISMATCH');
    if(typeof index.host!=='string'||!/^[-a-z0-9]+\.svc\.[-a-z0-9.]+\.pinecone\.io$/u.test(index.host))fail('UNTRUSTED_INDEX_HOST');
    const origin=`https://${index.host}`;
    const failure=(error,path,phase,started,status)=>{
      report.dataFailures??=[];
      if(report.dataFailures.length<8)report.dataFailures.push({operation:['/query','/vectors/fetch','/vectors/upsert','/vectors/delete','/describe_index_stats'].includes(path)?path:'other',
        phase,code:pineconeFailureCode(error),elapsedMs:performance.now()-started,...(status===undefined?{}:{httpStatus:status})});
    };
    const meteredFetch=async(input,init)=>{
      const url=new URL(input);if(url.origin!==origin)fail('UNTRUSTED_INDEX_HOST');
      if(report.requests.data>=(load?1200:154))fail('DATA_OPERATION_LIMIT');
      const isRead=['/query','/vectors/fetch'].includes(url.pathname);
      if(load){
        const bytes=typeof init.body==='string'?Buffer.byteLength(init.body):0;
        if(bytes>1_800_000||report.usage.requestBytes+bytes>report.limits.maxRequestBytes)fail('REQUEST_BYTE_LIMIT');
        if(isRead&&report.usage.reservedReadUnits+10>report.limits.maxReadUnits)fail('READ_UNIT_LIMIT');
        report.usage.requestBytes+=bytes;if(isRead)report.usage.reservedReadUnits+=10;
      }
      report.requests.data++;
      const started=performance.now();let phase='headers';let status;
      const queryTiming=url.pathname==='/query'?queryTimings?.current():undefined;
      if(queryTiming)queryTiming.fetchStart=started;
      try{
      const response=await transport(input,init);if(!response.ok){report.lastHttpStatus=response.status;return response;}
      if(queryTiming)queryTiming.headers=performance.now();
      status=response.status;phase='body';
      if(!load)return response;
      const reader=response.body?.getReader();const parts=[];let size=0;
      if(reader)try{for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;
        if(size>4_194_304||report.usage.responseBytes+size>report.limits.maxResponseBytes)fail('RESPONSE_BYTE_LIMIT');parts.push(part.value);
      }}finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
      report.usage.responseBytes+=size;const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
      if(queryTiming)queryTiming.body=performance.now();
      if(isRead){
        phase='usage-json';
        const value=JSON.parse(new TextDecoder().decode(bytes));const units=value.usage?.read_units??value.usage?.readUnits;
        if(typeof units==='number'&&Number.isFinite(units)&&units>=0){
          report.usage.readsWithUsage++;report.usage.reportedReadUnits+=units;
          report.usage.reservedReadUnits+=Math.max(0,units-10);
        }else report.usage.readsWithoutUsage++;
        if(report.usage.reservedReadUnits>report.limits.maxReadUnits)fail('READ_UNIT_LIMIT');
      }
      if(queryTiming){queryTiming.usageEnd=performance.now();queryTiming.meterEnd=performance.now();}
      return new Response(size?bytes:null,{status:response.status,headers:response.headers});
      }catch(error){failure(error,url.pathname,phase,started,status);throw error;}
    };
    const nativeAdapter=pineconeVectorStore({endpoint:origin,headers:{'Api-Key':options.apiKey,'X-Pinecone-Api-Version':version},
      dimensions:1536,costMicros:0,collection:name,permissions:options.permissions,timeoutMs:10_000,maxConcurrent:load?4:1,fetch:meteredFetch});
    const adapter=load?Object.freeze({...nativeAdapter,query:input=>queryTimings.query(()=>nativeAdapter.query(input))}):nativeAdapter;
    if(load){
      const headers={'Api-Key':options.apiKey,'X-Pinecone-Api-Version':version,'Content-Type':'application/json'};
      const data=async(path,body,signal,method='POST')=>{
        const response=await meteredFetch(`${origin}${path}`,{method,headers,redirect:'error',
          ...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.any([signal,AbortSignal.timeout(10_000)])});
        if(!response.ok){await response.body?.cancel();fail('DATA_REJECTED');}
        const started=performance.now();try{return await response.json();}catch(error){failure(error,new URL(`${origin}${path}`).pathname,'decode-json',started,response.status);throw error;}
      };
      const host={inventory:async signal=>{
        const value=await data('/describe_index_stats',{},signal);
        if(!value.namespaces||typeof value.namespaces!=='object')fail('INVALID_INVENTORY');
        return Object.fromEntries(Object.entries(value.namespaces).map(([key,value])=>{
          if(!Number.isSafeInteger(value.vectorCount)||value.vectorCount<0)fail('INVALID_INVENTORY');return [key,value.vectorCount];
        }));
      },fetchBatch:async(namespace,ids,signal)=>{
        const params=new URLSearchParams({namespace});ids.forEach(id=>params.append('ids',id));
        return (await data(`/vectors/fetch?${params}`,undefined,signal,'GET')).vectors;
      }};
      options.progress?.('Running public-document corpus and sustained-load qualification');
      report.qualification=await qualifyPineconeLoad({adapter,host,corpus:options.corpus??await publicDocumentationCorpus(),profile:loadProfile,
        permissions:options.permissions,maxCostMicros:0,signal:controller.signal,progress:message=>{queryTimings.setStage(message);options.progress?.(message);}});
    }else{
      options.progress?.('Running native Pinecone adapter qualification');
      report.qualification=await qualifyRagAdapters({mode:'live',permissions:options.permissions,maxOperations:154,maxCostMicros:0,
      maxDurationMs:180_000,cleanupTimeoutMs:30_000,maxReadAttempts:10,visibilityDelayMs:1000,signal:controller.signal,
      profiles:[{id:'pinecone-starter-cosine',kind:'vector',adapter}]});
    }
    report.status=report.qualification.status;
  }catch(error){report.status=controller.signal.aborted?'cancelled':'failed';
    report.code=['OWNERSHIP_MISMATCH','NO_FREE_INDEX_SLOT','CONTROL_REJECTED','INDEX_NOT_READY','INDEX_PROFILE_MISMATCH','UNTRUSTED_INDEX_HOST'].includes(error.code)?error.code:'HOSTED_QUALIFICATION_FAILED';}
  finally{
    if(queryTimings){report.queryTimings=queryTimings.snapshot();queryTimings.close();}
    clearTimeout(deadline);options.signal?.removeEventListener('abort',abort);
    if(attempted){
      const cleanup=new AbortController();const cleanupDeadline=setTimeout(()=>cleanup.abort(),60_000);
      try{
        options.progress?.('Verifying ownership and deleting the disposable index');
        const index=await describe(cleanup.signal,'cleanup');
        if(!index&&creationUncertain)fail('CREATE_OUTCOME_UNCERTAIN');
        if(index){
          if(!ownsPineconeIndex(index,name,owner))fail('OWNERSHIP_MISMATCH');
          await control('DELETE',`/indexes/${name}`,undefined,cleanup.signal,'cleanup');
          let gone=false;
          for(let attempt=0;attempt<28;attempt++){
            if(!await describe(cleanup.signal,'cleanup')){gone=true;break;}await pause(1000,cleanup.signal);
          }
          if(!gone)fail('CLEANUP_UNCONFIRMED');
        }
        const listed=await control('GET','/indexes',undefined,cleanup.signal,'cleanup');
        if(!Array.isArray(listed?.indexes)||listed.indexes.some(index=>index.name===name))fail('CLEANUP_UNCONFIRMED');
        report.otherIndexNamesPreserved=initialNames.every(name=>listed.indexes.some(index=>index.name===name));
        if(!report.otherIndexNamesPreserved)fail('INDEX_LIST_CHANGED');
        report.indexCleanup='passed';
      }catch{report.indexCleanup='unconfirmed';report.status='failed';}
      finally{clearTimeout(cleanupDeadline);}
    }
    report.completedAt=new Date().toISOString();await persist();
  }
  return report;
}

export async function main(args,environment=process.env) {
  const load=args[2]==='--load';const approximate=load&&args[3]==='--approximate-scores';
  const flags=load?[...args.slice(0,2),...args.slice(approximate?4:3)]:args;
  if(flags.length!==4||flags[0]!=='--live'||flags[1]!=='--starter'||flags[2]!=='--out'||!flags[3]||flags[3].startsWith('--')){
    console.error('EXPLICIT_LIVE_STARTER_AND_REPORT_REQUIRED');return 2;
  }
  const output=resolve(flags[3]);const sourcePaths=['scripts/pinecone-live-check.mjs','scripts/live/rag-checks.mjs',
    'scripts/live/pinecone-load-checks.mjs','scripts/live/rag-load-checks.mjs',
    'scripts/live/pinecone-query-timings.mjs',
    'extensions/vector-pinecone/src/index.ts','packages/rag/src/http.ts','packages/rag/src/validation.ts'];
  const sourceHashes=Object.fromEntries(await Promise.all(sourcePaths.map(async path=>[path,createHash('sha256').update(await readFile(new URL(`../${path}`,import.meta.url))).digest('hex')])));
  const persist=async report=>{
    await mkdir(dirname(output),{recursive:true});const pending=`${output}.tmp`;
    await writeFile(pending,JSON.stringify({...report,runtime:{node:process.version,platform:process.platform},sourceHashes},null,2)+'\n',{mode:0o600,flush:true});
    await rename(pending,output);
  };
  const controller=new AbortController();const cancel=()=>controller.abort();process.on('SIGINT',cancel);process.on('SIGTERM',cancel);
  try{
    const report=await qualifyPineconeStarter({starterConfirmed:true,maxCostMicros:0,apiKey:environment.PINECONE_API_KEY,profile:load?'load':'compatibility',
      ...(approximate?{loadProfile:{scorePolicy:'provider-approximate'}}:{}),
      permissions:{allow:['rag:qualify','rag:transport:pinecone','rag:admin:pinecone',...(load?['rag:qualify:load']:[])]},onReport:persist,signal:controller.signal,
      progress:message=>console.log(message)});
    console.log(`Pinecone qualification: ${report.status}; index cleanup: ${report.indexCleanup}.`);return report.status==='passed'?0:1;
  }catch{console.error('HOSTED_QUALIFICATION_REFUSED');return 2;}
  finally{process.removeListener('SIGINT',cancel);process.removeListener('SIGTERM',cancel);}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)process.exitCode=await main(process.argv.slice(2));
