import {AsyncLocalStorage} from 'node:async_hooks';
import {channel} from 'node:diagnostics_channel';
import {performance} from 'node:perf_hooks';
import {summarizeLatency} from './rag-load-checks.mjs';

/**
 * Owner-only query tracing. Never copy diagnostic request/response objects: they can contain credentials.
 * Only numeric timings, booleans and caller-selected stage labels survive. Unsubscribe after each run.
 */
export function pineconeQueryTimings() {
  const context=new AsyncLocalStorage();const requests=new WeakMap();const sockets=new WeakSet();const rows=[];
  let stage='setup';const subscriptions=[];
  const subscribe=(name,handler)=>{const target=channel(name);target.subscribe(handler);subscriptions.push([target,handler]);};
  subscribe('undici:request:create',({request})=>{
    const row=context.getStore();if(row&&request&&typeof request==='object'){row.created=performance.now();requests.set(request,row);}
  });
  subscribe('undici:client:sendHeaders',({request,socket})=>{
    const row=request&&requests.get(request);if(!row)return;
    row.sent=performance.now();if(socket&&typeof socket==='object'){row.reused=sockets.has(socket);sockets.add(socket);}
  });
  subscribe('undici:request:bodySent',({request})=>{const row=request&&requests.get(request);if(row)row.bodySent=performance.now();});
  return {
    setStage(value){if(['setup','scoped-nearest-records','warmup-reference-recall','sustained-paced-retrieval'].includes(value))stage=value;},
    current:()=>context.getStore(),
    async query(body){
      const row={stage,start:performance.now()};
      return context.run(row,async()=>{try{return await body();}finally{row.end=performance.now();if(rows.length<1200)rows.push(row);}});
    },
    snapshot(){
      const summarize=group=>{
        const metric=select=>{const values=group.map(select).filter(value=>typeof value==='number'&&Number.isFinite(value));return values.length?summarizeLatency(values.map(value=>Math.max(0,value)),0):null;};
        return {queries:group.length,
          totalAdapterMs:metric(row=>row.end-row.start),
          beforeFetchMs:metric(row=>row.fetchStart===undefined?undefined:row.fetchStart-row.start),
          socketWaitMs:metric(row=>row.sent===undefined||row.created===undefined?undefined:row.sent-row.created),
          fetchToHeadersMs:metric(row=>row.headers===undefined?undefined:row.headers-row.fetchStart),
          sentToHeadersMs:metric(row=>row.headers===undefined||row.bodySent===undefined?undefined:row.headers-row.bodySent),
          bodyTransferAndBufferMs:metric(row=>row.body===undefined?undefined:row.body-row.headers),
          usageDecodeMs:metric(row=>row.usageEnd===undefined?undefined:row.usageEnd-row.body),
          afterMeterMs:metric(row=>row.meterEnd===undefined?undefined:row.end-row.meterEnd),
          reusedSocketQueries:group.filter(row=>row.reused===true).length,newSocketQueries:group.filter(row=>row.reused===false).length,
          socketTimingMissing:group.filter(row=>row.reused===undefined).length};
      };
      return {kind:'query-phase-timings',coverage:'All adapter queries, grouped by phase; missing socket events mean unavailable, not zero.',
        phases:Object.fromEntries([...new Set(rows.map(row=>row.stage))].map(value=>[value,summarize(rows.filter(row=>row.stage===value))]))};
    },
    close(){for(const[target,handler]of subscriptions)target.unsubscribe(handler);context.disable();},
  };
}
