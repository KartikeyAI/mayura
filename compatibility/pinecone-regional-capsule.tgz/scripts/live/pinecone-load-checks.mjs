import {randomUUID,createHash} from 'node:crypto';
import {readdir,readFile} from 'node:fs/promises';
import {performance,monitorEventLoopDelay} from 'node:perf_hooks';
import {isDeepStrictEqual} from 'node:util';
import {vectorFixture,exactNeighbors,summarizeLatency} from './rag-load-checks.mjs';
import {sha256Hex} from '../../packages/core/dist/host.js';
import {scopeKey} from '../../packages/rag/dist/host.js';

const fail=code=>{throw Object.assign(new Error(code),{code});};
const integer=(value,min,max)=>{if(!Number.isSafeInteger(value)||value<min||value>max)fail('INVALID_PROFILE');return value;};
const wait=(ms,signal)=>new Promise((resolve,reject)=>{
  const finish=()=>{clearTimeout(timer);signal.removeEventListener('abort',abort);resolve();};
  const abort=()=>{clearTimeout(timer);signal.removeEventListener('abort',abort);reject(new Error('CANCELLED'));};
  const timer=setTimeout(finish,Math.max(0,ms));signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();
});

/** A declared, bounded workload. CLI uses these defaults; smaller profiles support offline failure tests. */
export function pineconeLoadProfile(input={}) {
  const scorePolicy=input.scorePolicy??'exact';if(!['exact','provider-approximate'].includes(scorePolicy))fail('INVALID_PROFILE');
  const records=integer(input.records??5000,64,5000);const decoys=integer(input.decoys??500,16,500);
  const durationMs=integer(input.durationMs??300_000,100,300_000);const qps=integer(input.qps??2,1,2);
  const auditBatchSize=32;
  const requiredOperations=Math.ceil(records/32)+3*Math.ceil(decoys/32)+30+Math.ceil(records/auditBatchSize)+3*Math.ceil(decoys/auditBatchSize)
    +4+24+Math.ceil(durationMs*qps/1000)+Math.ceil(records/128)+3*Math.ceil(decoys/128)+30;
  if(requiredOperations>1200)fail('OPERATION_LIMIT');
  return Object.freeze({records,decoys,totalVectors:records+3*decoys,dimensions:1536,durationMs,qps,concurrency:4,maxQueued:16,
    maxOperations:1200,requiredOperations,maxP95Ms:1000,minMeanRecallAt10:.95,minPerQueryRecallAt10:.8,scorePolicy,auditBatchSize});
}

/** Match the owner's existing bounded envelope; never truncate the five-minute window with a shorter inner timer. */
export function pineconeLoadWorkDuration(profile) { return pineconeLoadProfile(profile).durationMs+540_000; }

/** Read public documentation only, ignoring symlinks. Repetition scales volume; embeddings remain synthetic. */
export async function publicDocumentationCorpus() {
  const root=new URL('../../docs/',import.meta.url);const files=[];const chunks=[];
  const visit=async(relative='')=>{
    for(const entry of (await readdir(new URL(relative,root),{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
      const path=`${relative}${entry.name}`;
      if(entry.isDirectory())await visit(`${path}/`);
      else if(entry.isFile()&&entry.name.endsWith('.md')){
        const raw=await readFile(new URL(path,root),'utf8');const text=raw.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/u,'').replace(/\r\n/gu,'\n').trim();
        const hash=createHash('sha256').update(text).digest('hex');files.push({path:`docs/${path}`,sha256:hash});
        for(let offset=0;offset<text.length;offset+=2048){
          const body=text.slice(offset,offset+2048).trim();if(body)chunks.push({text:body,source:`docs/${path}`,revision:hash});
        }
      }
    }
  };
  await visit();if(!chunks.length)fail('EMPTY_CORPUS');
  return {chunks,manifest:{kind:'Public Mayura documentation chunks, repeated deterministically to workload size',
    sourceFiles:files,uniqueSourceChunks:chunks.length,sha256:createHash('sha256').update(JSON.stringify(chunks)).digest('hex'),
    embeddings:'Seeded normalized synthetic clustered vectors; no embedding-model or semantic-quality claim'}};
}

/**
 * Hosted corpus audit and paced retrieval. All fixtures are invocation-owned; writes are attempted once.
 * Every acknowledged vector is fetched before load, and independent cleanup verifies zero remaining records.
 */
export async function qualifyPineconeLoad(options) {
  if(!options.permissions?.allow?.includes('rag:qualify:load'))fail('PERMISSION_DENIED');
  if(options.maxCostMicros!==0||options.adapter.location!=='hosted'||options.adapter.costMicros!==0||options.adapter.dimensions!==1536)fail('STARTER_ZERO_COST_REQUIRED');
  const profile=pineconeLoadProfile(options.profile);const {adapter,host,corpus}=options;
  if(!corpus?.chunks?.length||typeof host?.inventory!=='function'||typeof host?.fetchBatch!=='function')fail('INVALID_CONFIG');
  const control=new AbortController();const relay=()=>control.abort();options.signal?.addEventListener('abort',relay,{once:true});if(options.signal?.aborted)relay();
  const workDurationMs=pineconeLoadWorkDuration(profile);
  const timer=setTimeout(relay,workDurationMs);let operations=0;let uncertain=false;const touched=[];
  const report={format:1,kind:'pinecone-starter-sustained-load',profile,workDurationMs,corpus:corpus.manifest,status:'failed',checks:[],cleanup:'not-started',ragStatus:'experimental',productionReady:false};
  const invoke=async(body,signal=control.signal)=>{
    signal.throwIfAborted();if(++operations>profile.maxOperations)fail('OPERATION_LIMIT');let abort;
    try{return await Promise.race([Promise.resolve().then(()=>body(signal)),new Promise((_,reject)=>{
      abort=()=>reject(new Error('CANCELLED'));signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();
    })]);}finally{if(abort)signal.removeEventListener('abort',abort);}
  };
  const check=async(name,body)=>{
    options.progress?.(name);try{const detail=await body();report.checks.push({name,status:'passed',...detail});}
    catch(error){report.checks.push({name,status:'failed',code:['CONTRACT_FAILED','RECALL_FAILED','VISIBILITY_TIMEOUT','LOAD_SLO_FAILED','OPERATION_LIMIT'].includes(error.code)?error.code:'ADAPTER_FAILED'});throw error;}
  };
  const nonce=`pcload-${randomUUID()}`;const scope={principalId:`${nonce}-owner`,projectId:nonce};
  const partitions=[{scope,space:`${nonce}-main`,count:profile.records},
    {scope:{...scope,principalId:`${nonce}-other`},space:`${nonce}-main`,count:profile.decoys},
    {scope:{...scope,projectId:`${nonce}-other`},space:`${nonce}-main`,count:profile.decoys},
    {scope,space:`${nonce}-other`,count:profile.decoys}].map(partition=>({...partition,namespace:sha256Hex(scopeKey(partition.scope,partition.space))}));
  const id=index=>`chunk${String(index).padStart(6,'0')}`;
  const entry=(index,partition)=>{
    const source=corpus.chunks[index%corpus.chunks.length];
    return {chunk:{id:id(index),documentId:`doc${index}`,revision:source.revision,text:source.text,
      reference:`https://example.invalid/public-mayura-docs/${source.source}#${partition}-${index}`,
      metadata:{topic:`t${Math.floor(index/32)%8}`,published:index%3!==0},sensitivity:'public',start:0,end:source.text.length},
      values:vectorFixture(1536,index)};
  };
  const primary=Array.from({length:profile.records},(_,index)=>entry(index,0));
  const queries=Array.from({length:24},(_,index)=>{
    const vector=vectorFixture(1536,index*17+7,true);
    const filter=index%3===0?{}:index%3===1?{topic:`t${index%8}`}:{topic:`t${index%8}`,published:true};
    const expected=exactNeighbors(primary,vector,filter,10);
    return {vector,filter,expected,scores:new Map(expected.map(hit=>[hit.id,hit.score])),cohort:index%3===0?'unfiltered':index%3===1?'topic':'topic-and-boolean'};
  });
  const read=(partition,query,signal=control.signal)=>invoke(signal=>adapter.query({...partition,vector:Array.from(query.vector),filter:query.filter,limit:10,signal}),signal);
  let scoreErrors=0;let totalAbsoluteError=0;let maximumAbsoluteError=0;
  const quality=(rows,query)=>{
    const invalid=(reason,details={})=>{
      report.firstInvalidResult??={reason,cohort:query.cohort,...details};fail('CONTRACT_FAILED');
    };
    if(!Array.isArray(rows)||rows.length!==query.expected.length)invalid('result-count',{expected:query.expected.length,actual:Array.isArray(rows)?rows.length:null});const seen=new Set();
    for(const hit of rows){
      const row=primary[Number(hit.chunk?.id?.slice(5))];
      if(!row||seen.has(hit.chunk.id)||!isDeepStrictEqual(hit.chunk,row.chunk)||!Number.isFinite(hit.score)
        ||!Object.entries(query.filter).every(([key,value])=>row.chunk.metadata[key]===value))invalid('identity-metadata-or-filter');
      if(!query.scores.has(hit.chunk.id))query.scores.set(hit.chunk.id,exactNeighbors([row],query.vector,{},1)[0].score);
      const error=Math.abs(hit.score-query.scores.get(hit.chunk.id));scoreErrors++;totalAbsoluteError+=error;maximumAbsoluteError=Math.max(maximumAbsoluteError,error);
      if(profile.scorePolicy==='exact'&&error>.0001)invalid('cosine-score',{id:hit.chunk.id,actual:hit.score,expected:query.scores.get(hit.chunk.id),absoluteError:error});seen.add(hit.chunk.id);
    }
    for(let index=1;index<rows.length;index++)if(rows[index].score>rows[index-1].score+.000001)invalid('score-order');
    return query.expected.length?query.expected.filter(hit=>seen.has(hit.id)).length/query.expected.length:1;
  };
  const inventory=async(empty,signal=control.signal)=>{
    for(let attempt=0;attempt<30;attempt++){
      const counts=await invoke(signal=>host.inventory(signal),signal);
      if(Object.keys(counts).some(namespace=>!partitions.some(partition=>partition.namespace===namespace)))fail('CONTRACT_FAILED');
      if(partitions.every(partition=>(counts[partition.namespace]??0)===(empty?0:partition.count)))return;
      if(attempt<29)await wait(1000,signal);
    }
    fail('VISIBILITY_TIMEOUT');
  };
  try{
    await check('bounded-document-corpus-ingestion',async()=>{
      for(let partition=0;partition<partitions.length;partition++){
        const target=partitions[partition];touched.push(target);
        for(let offset=0;offset<target.count;offset+=32){
          const entries=Array.from({length:Math.min(32,target.count-offset)},(_,i)=>partition===0?primary[offset+i]:entry(offset+i,partition));
          try{await invoke(signal=>adapter.upsert(target.scope,target.space,entries.map(row=>({...row,values:Array.from(row.values)})),signal));}
          catch(error){uncertain=true;throw error;}
        }
      }
      return {vectors:profile.totalVectors};
    });
    await check('full-corpus-count-and-fetch-audit',async()=>{
      await inventory(false);let audited=0;
      for(let partition=0;partition<partitions.length;partition++){
        const target=partitions[partition];
        for(let offset=0;offset<target.count;offset+=profile.auditBatchSize){
          const ids=Array.from({length:Math.min(profile.auditBatchSize,target.count-offset)},(_,i)=>id(offset+i));
          const rows=await invoke(signal=>host.fetchBatch(target.namespace,ids,signal));
          if(!rows||Object.keys(rows).length!==ids.length)fail('CONTRACT_FAILED');
          for(let i=0;i<ids.length;i++){
            const expected=entry(offset+i,partition);const row=rows[ids[i]];
            if(row?.id!==ids[i]||row.metadata?.mayuraNamespace!==target.namespace
              ||!isDeepStrictEqual(JSON.parse(row.metadata.mayuraChunk),expected.chunk)||!Array.isArray(row.values)||row.values.length!==1536
              ||row.values.some((value,index)=>!Number.isFinite(value)||Math.abs(value-expected.values[index])>1e-6))fail('CONTRACT_FAILED');
            if(!Object.entries(expected.chunk.metadata).every(([key,value])=>row.metadata[key]===value))fail('CONTRACT_FAILED');audited++;
          }
        }
      }
      return {audited};
    });
    await check('scoped-nearest-records',async()=>{
      for(let partition=0;partition<partitions.length;partition++){
        const target=partitions[partition];const expected=entry(target.count-1,partition);
        const rows=await invoke(signal=>adapter.query({...target,vector:Array.from(expected.values),filter:{},limit:1,signal}));
        if(rows.length!==1||!isDeepStrictEqual(rows[0].chunk,expected.chunk))fail('CONTRACT_FAILED');
      }
    });
    await check('warmup-reference-recall',async()=>{
      const recalls=[];for(const query of queries)recalls.push(quality(await read(partitions[0],query),query));
      const mean=recalls.reduce((a,b)=>a+b,0)/recalls.length;const minimum=Math.min(...recalls);
      report.warmup={meanRecallAt10:mean,minRecallAt10:minimum};
      if(mean<profile.minMeanRecallAt10||minimum<profile.minPerQueryRecallAt10)fail('RECALL_FAILED');return {meanRecallAt10:mean,minRecallAt10:minimum};
    });
    await check('sustained-paced-retrieval',async()=>{
      const samples=[];const rec=[];const cohorts=new Map();const lag=[];const queueWait=[];const active=new Set();const pending=[];
      let errors=0;let late=0;let skipped=0;let maximumQueued=0;
      const interval=1000/profile.qps;const offered=Math.ceil(profile.durationMs/interval);const started=performance.now();
      const loop=monitorEventLoopDelay({resolution:10});loop.enable();const utilization=performance.eventLoopUtilization();
      const pump=()=>{
        while(active.size<profile.concurrency&&pending.length){
          // Timer rounding may wake just before the scheduled arrival; queue residence cannot be negative.
          const job=pending.shift();const query=queries[job.slot%queries.length];queueWait.push(Math.max(0,performance.now()-job.arrival));
          const work=(async()=>{try{
            const recall=quality(await read(partitions[0],query),query);const ms=performance.now()-job.arrival;
            samples.push(ms);rec.push(recall);if(!cohorts.has(query.cohort))cohorts.set(query.cohort,{latency:[],recall:[]});
            cohorts.get(query.cohort).latency.push(ms);cohorts.get(query.cohort).recall.push(recall);
          }catch{errors++;}})();active.add(work);void work.finally(()=>{active.delete(work);pump();});
        }
      };
      try{
        for(let slot=0;slot<offered;slot++){
          if(slot&&slot%(profile.qps*30)===0)options.progress?.(`load: ${samples.length} completed, ${errors} errors, ${late+skipped} missed`);
          const arrival=started+slot*interval;await wait(arrival-performance.now(),control.signal);const drift=performance.now()-arrival;lag.push(Math.max(0,drift));
          if(drift>Math.max(100,interval)){late++;continue;}
          if(active.size>=profile.concurrency&&pending.length>=profile.maxQueued){skipped++;continue;}
          pending.push({slot,arrival});pump();maximumQueued=Math.max(maximumQueued,pending.length);
        }
        await wait(started+profile.durationMs-performance.now(),control.signal);
      }finally{while(active.size||pending.length){pump();await Promise.allSettled([...active]);}loop.disable();}
      const mean=rec.length?rec.reduce((a,b)=>a+b,0)/rec.length:0;const minimum=rec.length?Math.min(...rec):0;
      report.retrieval={offeredQueries:offered,completedQueries:samples.length,errors,late,skipped,maximumQueued,latencyIncludesQueue:true,
        ...summarizeLatency(samples,performance.now()-started),meanRecallAt10:mean,minRecallAt10:minimum,
        schedulerLag:summarizeLatency(lag,0),queueWait:summarizeLatency(queueWait,0),
        eventLoop:{p99Ms:loop.percentile(99)/1e6,maxMs:loop.max/1e6,utilization:performance.eventLoopUtilization(utilization).utilization},
        filters:Object.fromEntries([...cohorts].map(([name,group])=>[name,{...summarizeLatency(group.latency,0),
          meanRecallAt10:group.recall.reduce((a,b)=>a+b,0)/group.recall.length,minRecallAt10:Math.min(...group.recall)}]))};
      if(errors||late+skipped>offered*.01||samples.length<offered*.99||report.retrieval.requestsPerSecond<profile.qps*.99
        ||report.retrieval.p95Ms>profile.maxP95Ms||mean<profile.minMeanRecallAt10||minimum<profile.minPerQueryRecallAt10)fail('LOAD_SLO_FAILED');
    });
    report.status='passed';
  }catch{report.status=control.signal.aborted?'cancelled':'failed';}
  finally{
    const cleanup=new AbortController();const cleanupTimer=setTimeout(()=>cleanup.abort(),60_000);
    try{
      // Unique ID batches are attempted once, under the same four-slot transport cap as reads.
      // Drain every admitted delete before checking emptiness or letting the owner remove the index.
      const batches=[];for(const target of touched)for(let offset=0;offset<target.count;offset+=128)
        batches.push({target,ids:Array.from({length:Math.min(128,target.count-offset)},(_,i)=>id(offset+i))});
      let next=0;let failed=false;
      const workers=await Promise.allSettled(Array.from({length:Math.min(profile.concurrency,batches.length)},async()=>{
        while(!failed&&next<batches.length){const {target,ids}=batches[next++];
          try{await invoke(signal=>adapter.delete(target.scope,target.space,ids,signal),cleanup.signal);}
          catch(error){failed=true;throw error;}
        }
      }));
      const rejected=workers.find(worker=>worker.status==='rejected');if(rejected)throw rejected.reason;
      await inventory(true,cleanup.signal);report.cleanup=uncertain?'unconfirmed':'passed';
    }catch(error){report.cleanup='failed';report.cleanupFailure={code:['VISIBILITY_TIMEOUT','CONTRACT_FAILED','OPERATION_LIMIT','DATA_REJECTED'].includes(error.code)?error.code:cleanup.signal.aborted?'CANCELLED':'ADAPTER_FAILED'};}
    finally{clearTimeout(cleanupTimer);clearTimeout(timer);options.signal?.removeEventListener('abort',relay);}
    if(report.cleanup!=='passed')report.status='failed';report.operations=operations;
    report.scoreAccuracy={policy:profile.scorePolicy,count:scoreErrors,meanAbsoluteError:scoreErrors?totalAbsoluteError/scoreErrors:null,maxAbsoluteError:scoreErrors?maximumAbsoluteError:null};
  }
  return report;
}
